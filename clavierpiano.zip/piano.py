from tkinter import *           # pour la fenetre et le canva
from PIL import Image,ImageTk   # pour le chargmement de l'image piano    
from winsound import Beep       # pour l'emission du son
from os import *                # pour la recupération du chemin de l'application et de l'image
class piano:       # classe piano squelette de l'application
    
    Notes4oct={"la":440.00,"la_bemol":466.94,
                "si":493.88,"do":261.63,"do_bemol":277.645,
                "re":293.66,"re_bemol":311.645,
                "mi":329.63,"fa":349.23,"fa_bemol":370.615,
                "sol":392,"sol_bemol":416}  #les fréquences de base des notes
    skinImages=["akai.jpg","piano_clav.jpg"]   # les claviers possibles
    tempo=350                                   # durée de la note
    fenref=None                                 # reference à la fenetre
    chemin=getcwd().replace("\\","/")           # recupération du chemin de l'application
    skindefaut=0                                # le clavier par défaut
    largeurTouche=0                             # largeur de la touche du clavier( touche blanche)
    largeurBemol=0                              # largeur de la touche noir
    origine=(0,0)                               # position dans l'image du placement du clavier
    nbOctave=2                                  # nombre d'octaves du clavier
    canv=None                                   # canva de la fenetre qui contiendra l'image du piano
    tclavier=None                               # reference au clavier qui sera crée
    
    def interfaceg(self):                   
        """ methode pour la création de l'interface graphique """    
        self.fenref=Toplevel()                                              # création de la fenetre        
        self.fenref.title("MonPiano")                                       # titree de la fentre
        img=Image.open(self.chemin+"/"+self.skinImages[self.skindefaut])    # ouverture de l'image du piano
        imsize=img.size                                                     # recupération  de la taille de l'image
        imgph=ImageTk.PhotoImage(img)                                       # chrgement de l'image avec PIL
        self.fenref.size=imsize                                   # adaptation de la taille de la fenetre à celle de l'image 
        self.fenref.resizable(False,False) # rendre la fenetre non redimentionable
        self.canv=Canvas(self.fenref,width=imsize[0],height=imsize[1])  # creation du canva
        self.canv.create_image(0,0,image=imgph,anchor=NW)               # placemnt de l'image dans le canva
        self.activeClav()                                               # appel à la fonction d'activation du clavier     
        self.canv.pack()                                                #  refresh du canva
        self.fenref.bind("q",lambda event, touche="do0": self.keybSon(touche))  # association de quelques touches du clavier 
        self.fenref.bind("s",lambda event, touche="re0": self.keybSon(touche))  # avec des notes du piano question d'utiliser 
        self.fenref.bind("d",lambda event, touche="mi0": self.keybSon(touche))  # les touches directement au lieu de la souris
        self.fenref.bind("f",lambda event, touche="fa0": self.keybSon(touche))  # on utilise l'evenement clavier et la fonction
        self.fenref.bind("g",lambda event, touche="sol0": self.keybSon(touche)) # bind et la touche correspondnte
        self.fenref.bind("h",lambda event, touche="la0": self.keybSon(touche))
        self.fenref.bind("j",lambda event, touche="si0": self.keybSon(touche))
        self.fenref.bind("k",lambda event, touche="do1": self.keybSon(touche))
        self.fenref.bind("l",lambda event, touche="re1": self.keybSon(touche))
        self.fenref.bind("m",lambda event, touche="mi1": self.keybSon(touche))
       
        self.fenref.mainloop()              # la boucle principale d'execution
        
        
    def __init__(self,chemin):              # contructeur de la classe
        self.interfaceg()                   # appel à la fonction précédente
        
    def mapTouches(self):                   # création des touches qui seront actives sur le clavier

        mp={}                               # dictionnaire des dimentions des touches(polygone qui auront les mêmes 
                                            # dimensions que les touches du clavier de l'image
        
            
        if self.skindefaut==0:              #   premier clavier akai : piano num:0///
            self.origine=(132,56)           # position de placement du clavier dans l'image       
            self.largeurTouche=64           # largeur de la touche des notes (blaches)
            self.largeurBemol=40            # largeur des notes bémols (noires)
            La=["La",(18,0),(18,158),(0,158),(0,262),(62,262),(62,158),(46,158),(46,0),(18,0)]      # dimension du la note la 
            La_bemol=["La_bemol",(0,0),(0,158),(35,158),(35,0),(0,0)]                               # dimension du la note labemol
            Si=["Si",(10,0),(10,158),(0,158),(0,262),(64,262),(64,0),(10,0)]                        ## dimension du la note si
            Do=["Do",(0,0),(0,262),(64,262),(64,158),(42,158),(42,0),(0,0)]                         # dimension du la note do
            Sol=["Sol",(16,0),(16,158),(0,158),(0,262),(62,262),(62,158),(46,158),(46,0),(16,0)]    # dimension du la note sol
            Re=["Re",(16,0),(16,158),(0,158),(0,262),(62,262),(62,158),(46,158),(46,0),(16,0)]      # dimension du la note re
        
        
        elif self.skindefaut==1:   # deuxième clavier  : piaon num:1
            self.origine=(0,53)     # position de placement du clavier dans l'image 
            self.largeurTouche=23   # largeur de la touche des notes (blaches)
            self.largeurBemol=14     # largeur des notes bémols (noires)
            La=["La",(7,0),(7,82),(0,82),(0,133),(23,133),(23,82),(16,82),(16,0),(7,0)] # dimension du la note la
            La_bemol=["La_bemol",(0,0),(0,82),(13,82),(13,0),(0,0)]                      # dimension du la note labemol
            Si=["Si",(7,0),(7,82),(0,82),(0,133),(23,133),(23,0),(7,0)]                 # dimension du la note si
            Do=["Do",(0,0),(0,133),(23,133),(23,82),(16,82),(16,0),(0,0)]               # dimension du la note do
            Sol=["Sol",(7,0),(7,82),(0,82),(0,133),(23,133),(23,82),(16,82),(16,0),(7,0)]  # dimension du la note sol
            Sol=["Re",(7,0),(7,82),(0,82),(0,133),(23,133),(23,82),(16,82),(16,0),(7,0)]  # dimension du la note sol
            
        Do_bemol=La_bemol[:]        # do bemol calqué du la bemol
        Do_bemol[0]="Do_bemol"      #non de la touche
       
        Re_bemol=La_bemol[:]        #re bemol aussi calqué de la bemol
        Re_bemol[0]="Re_bemol"      # nom de la touche
        Mi=Si[:]                    # mi calqué du si
        Mi[0]="Mi"                  # nom de la touche
        Fa=Do[:]                    # de meme pour fa
        Fa[0]="Fa"                  # idem
        Fa_bemol=La_bemol[:]        # idem pour fa bemol
        Fa_bemol[0]="Fa_bemol"      # et son nom
       
        Sol_bemol=La_bemol[:]        # idem pour sol bemol   
        Sol_bemol[0]="Sol_bemol"      # nom de la touche  
        mp["la"]=La                 # ajout au dictionnaire
        mp["la_bemol"]=La_bemol     
        mp["si"]=Si
        mp["do"]=Do
        mp["do_bemol"]=Do_bemol
        mp["re"]=Re
        mp["re_bemol"]=Re_bemol
        mp["mi"]=Mi
        mp["fa"]=Fa
        mp["fa_bemol"]=Fa_bemol
        mp["sol"]=Sol
        mp["sol_bemol"]=Sol_bemol
        return mp                    #   recupération du dictionnaire
        
    def modifCoords(self,lcoord,M):  # change les coordonnées de l touche relativement a la position M(x,y)
        nvcoord=[]                      # liste qui contitendra les coordonées de la touche
        nvcoord.append(lcoord[0])       # et positionement de cette touche dans le clavier 
        for i in range (1,len(lcoord)):
            nvcoord.append([lcoord[i][0]+M[0],lcoord[i][1]+M[1]])  # calcul des nouveaux coordonnées
            
        return nvcoord                  # recupération des coordonées de la touche dans le clavier
    def creerClavier(self,nboctave,origine): # recupère le clavier contennant le nboctave de touches
        mp=self.mapTouches()    # recupération du dictionnaire des touches
        clavier=[]              # liste qui contiendra les nouvelles valeurs des coordonnées et dimentions
        do=mp["do"]             # récuparation des dimensions de la touche do
        do_bemol=mp["do_bemol"] # récuparation des dimensions de la touche do_bemol
        re=mp["re"]             # récuparation des dimensions de la touche re
        re_bemol=mp["re_bemol"] # récuparation des dimensions de la touche re_bemol
        mi=mp["mi"]             # récuparation des dimensions de la touche mi
        fa=mp["fa"]             # récuparation des dimensions de la touche fa
        fa_bemol=mp["fa_bemol"] # récuparation des dimensions de la touche fa_bemol
        sol=mp["sol"]           # récuparation des dimensions de la touche sol
        sol_bemol=mp["sol_bemol"]   # récuparation des dimensions de la touche sol_bemol
        la=mp["la"]             # récuparation des dimensions de la touche la
        la_bemol=mp["la_bemol"] # récuparation des dimensions de la touche la_bemol
        si=mp["si"]             # récuparation des dimensions de la touche si
        a,b=origine[0],origine[1]  # origine point de placement de la touche
        
        for i in range(0,nboctave):  #boucle de placement des touches dans le clavier
           clavier.append(self.modifCoords(do,(a,b)))
           clavier.append(self.modifCoords(do_bemol,(a+self.largeurTouche-self.largeurBemol//2,b)))
           a+=self.largeurTouche
           clavier.append(self.modifCoords(re,(a,b)))
           clavier.append(self.modifCoords(re_bemol,(a+self.largeurTouche-self.largeurBemol//2,b)))
           a+=self.largeurTouche            
           clavier.append(self.modifCoords(mi,(a,b)))
           a+=self.largeurTouche
           clavier.append(self.modifCoords(fa,(a,b)))
           clavier.append(self.modifCoords(fa_bemol,(a+self.largeurTouche-self.largeurBemol//2,b)))
           a+=self.largeurTouche
           clavier.append(self.modifCoords(sol,(a,b)))
           clavier.append(self.modifCoords(sol_bemol,(a+self.largeurTouche-self.largeurBemol//2,b)))
           a+=self.largeurTouche
           clavier.append(self.modifCoords(la,(a,b)))
           clavier.append(self.modifCoords(la_bemol,(a+self.largeurTouche-self.largeurBemol//2,b)))
           a+=self.largeurTouche
           clavier.append(self.modifCoords(si,(a,b)))
           a+=self.largeurTouche
          
        return clavier    # recupération du clavie du piano
            
    def activeClav(self):   
        """ activation des touches et création des polygones graphiques"""
        mp=self.mapTouches()  # mappage des touches
        self.tclavier=self.creerClavier(self.nbOctave,self.origine) # recupérations du clavier
        
        i=0
        for x in self.tclavier:   # création des polygones des touches 
            lp=[]
            
            for m in range(1,len(x)):
                
                lp.append(x[m][0])
                lp.append(x[m][1])
            
            letag=str(x[0])+str(i//12)
            
            if 'bemol' in x[0] :
                touche=self.canv.create_polygon(lp, fill = 'black', outline = 'black',tag=letag,activefill='gray')
            else:
                touche=self.canv.create_polygon(lp, fill = 'white', outline = 'black',tag=letag, activefill='gray')
            self.canv.tag_bind( touche, "<Button-1>",self.donneSon) #placement des touches dans le canva
            i+=1
    
    def donneSon(self,event):
        """ fonction callback de l'evenement click sur le polygone """
        latouche=self.canv.gettags(CURRENT)[0]      # determination de la touche concernée
        numOctave=int(latouche[-1])
        nomTouche=latouche[:-1]
        frq=self.Notes4oct[str(nomTouche).lower()]   # recupération de la fréquence de la touche concernée
        frq=frq*(numOctave+1)                       # determination du numéro de l'octave coresspondante à la touche
        Beep(int(frq),self.tempo)                   # emmission de la note
    
    def keybSon(self,touche):                       
        """la meme fonction que la précédente mais avec la touche du clavier"""
        numOctave=int(touche[-1])       
        nomTouche=touche[:-1]
        self.canv.itemconfigure(touche,fill="gray")
        frq=self.Notes4oct[str(nomTouche).lower()]
        frq=frq*(numOctave+1)
        Beep(int(frq),self.tempo) 
        

            
            
pia=piano("")  # instanciation de la classe et lancement de l'application
